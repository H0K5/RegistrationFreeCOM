var actCtx = new ActiveXObject( "Microsoft.Windows.ActCtx" );
actCtx.Manifest = "C:\\Tools\\COM\\DynamicWrapperX\\AllTheThings.manifest";
try {
var DX = actCtx.CreateObject("SideBySide.X");
DX.MessageBox(0, "Hello, world!", "Test", 4);        // Call the function.
}
catch(e){}

